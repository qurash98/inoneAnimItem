package uz.anor_system.animcard.models

data class ProductData(
    val id: Int,
    val name: String,
    val resourceId: Int
)